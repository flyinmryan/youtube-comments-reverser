Description: This folder contains the source code for a browser extension named "Turbo YouTube Reverser". The extension is designed to provide functionality for reversing YouTube video playback. It includes a popup interface (`popup.html`, `popup.js`) and a content script (`content.js`) that interacts with YouTube pages.
Technologies: JavaScript, HTML, CSS (for popup), Browser Extension APIs.
Build/Run: To run this as a browser extension, you need to load it as an unpacked extension in your browser's extension management page (e.g., `chrome://extensions` for Chrome, `about:debugging#/runtime/this-firefox` for Firefox).
Debug: Browser extension debugging tools (available in the browser's developer tools) can be used to inspect the popup and content scripts.
